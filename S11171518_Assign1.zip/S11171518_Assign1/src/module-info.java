module Assign1 {
	requires junit;
}