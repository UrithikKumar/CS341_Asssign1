package q3test.edureka;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class JUNITCLASS {
@Test

public void setup()
{
String str ="This is an Invalid Input";
assertEquals("This is an Invalid Input",str);
}

}
