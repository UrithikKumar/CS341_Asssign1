package Assign1;
import java.util.*;

@SuppressWarnings("unused")
public class TermRate {

	public static void main(String args[]) {
		        int NUM_YEARS=0;
		        int NUM_MONTHS=0;
		        
		        Scanner sc = new Scanner(System.in);
		        System.out.println("Enter duration of year(s) and month(s) Please use a space between the numbers");
		        System.out.println("Please input answer in the format as '1 2' for example of 1 Year and 2 Months ");
		        NUM_YEARS=sc.nextInt();
		        NUM_MONTHS=sc.nextInt();
		        sc.close();
		        if (NUM_MONTHS<1||NUM_MONTHS>11)
		        {
		            System.out.println("Please enter correct Months between 1 and 11 ");
		            System.exit(1);
		            
		        }
		        else {
		            System.out.println("The interest will be : "+computeTermInterestRate(NUM_YEARS, NUM_MONTHS)+"%");
		        }
		    }
		    //Calculation on interest rate conducted below
		   public static float computeTermInterestRate(int numberOfYears, int numberOfMonths)
		   {
		     float InterestRate=(float)0.0;
		     int TOTAL_MONTHS=(numberOfYears*12)+numberOfMonths;
		     if (TOTAL_MONTHS>=1&&TOTAL_MONTHS<3)
		         InterestRate=(float)2.0;
		     if (TOTAL_MONTHS>=3&&TOTAL_MONTHS<=5)
		         InterestRate=(float)3.5;
		     if (TOTAL_MONTHS>=6&&TOTAL_MONTHS<=11)
		         InterestRate=(float)4.5;
		     if (TOTAL_MONTHS>=12&&TOTAL_MONTHS<=23)
		         InterestRate=(float)5.0;
		     else if (TOTAL_MONTHS>=24)
		         InterestRate=(float)6.0;
		     else //If input is apart from an y above it will return 9.9%
		         InterestRate =(float)9.9;
		     return InterestRate;
		   }
		    
		
}
